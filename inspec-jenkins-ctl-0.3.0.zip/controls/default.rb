# copyright: 2022, Stephanie Thompson

title 'Jenkins Controller'

# you add controls here
control 'java-installed' do                        # A unique ID for this control
  impact 1.0                                       # The criticality, if this control fails.
  title 'Java 11 Installation'                     # A human-readable title
  desc 'Checking that Java 11 is installed'
  describe 'java' do                               # The actual test
    its('version') { should cmp >= '11' }
  end
end
